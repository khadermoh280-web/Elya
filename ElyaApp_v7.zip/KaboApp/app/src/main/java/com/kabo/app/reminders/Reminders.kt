package com.kabo.app.reminders

import android.app.AlarmManager
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.BroadcastReceiver
import android.content.Context
import android.content.Intent
import androidx.core.app.NotificationCompat
import com.kabo.app.data.Store

object Reminders {
    private const val CHANNEL = "kabo_reminders"

    fun schedule(ctx: Context, id: Long, text: String, due: Long, priority: Int) {
        if (due <= System.currentTimeMillis()) return
        val am = ctx.getSystemService(Context.ALARM_SERVICE) as AlarmManager
        val pi = PendingIntent.getBroadcast(
            ctx, id.toInt(),
            Intent(ctx, ReminderReceiver::class.java).putExtra("text", text).putExtra("p", priority).putExtra("id", id),
            PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
        )
        val exactOk = android.os.Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()
        if (exactOk) am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, pi)
        else am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, due, pi)
    }

    fun notify(ctx: Context, id: Long, text: String, priority: Int) {
        val nm = ctx.getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "التذكيرات", NotificationManager.IMPORTANCE_HIGH)
        )
        val tag = when (priority) { 3 -> "عاجل جدًا"; 2 -> "مهم"; else -> "تذكير" }
        nm.notify(
            id.toInt(),
            NotificationCompat.Builder(ctx, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_popup_reminder)
                .setContentTitle(tag)
                .setContentText(text)
                .setStyle(NotificationCompat.BigTextStyle().bigText(text))
                .setPriority(if (priority >= 2) NotificationCompat.PRIORITY_MAX else NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .build()
        )
    }

    fun rescheduleAll(ctx: Context) {
        Store(ctx).tasks().filter { !it.done }.forEach { schedule(ctx, it.id, it.text, it.due, it.priority) }
    }
}

class ReminderReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        Reminders.notify(ctx, i.getLongExtra("id", 0), i.getStringExtra("text").orEmpty(), i.getIntExtra("p", 1))
    }
}

class BootReceiver : BroadcastReceiver() {
    override fun onReceive(ctx: Context, i: Intent) {
        if (i.action == Intent.ACTION_BOOT_COMPLETED) Reminders.rescheduleAll(ctx)
    }
}
