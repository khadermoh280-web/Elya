package com.kabo.app.assistant

import okhttp3.OkHttpClient
import okhttp3.Request
import org.json.JSONObject
import java.net.URLEncoder

/**
 * يجيب جواب قصير من النت. يستخدم ويكيبيديا العربية ثم DuckDuckGo.
 * بدون مفاتيح API. تقدر لاحقًا تبدله بنموذج ذكاء اصطناعي.
 */
object Answerer {
    private val client = OkHttpClient()

    private fun get(url: String): String? = try {
        client.newCall(Request.Builder().url(url).header("User-Agent", "KaboApp/1.0").build())
            .execute().use { if (it.isSuccessful) it.body?.string() else null }
    } catch (e: Exception) { null }

    fun answer(question: String): String {
        val q = URLEncoder.encode(question.trim(), "UTF-8")

        // 1) ويكيبيديا العربية: بحث ثم ملخص أول نتيجة
        get("https://ar.wikipedia.org/w/api.php?action=query&list=search&srsearch=$q&format=json&srlimit=1")
            ?.let { body ->
                val hits = JSONObject(body).getJSONObject("query").getJSONArray("search")
                if (hits.length() > 0) {
                    val title = URLEncoder.encode(hits.getJSONObject(0).getString("title"), "UTF-8")
                    get("https://ar.wikipedia.org/api/rest_v1/page/summary/$title")?.let { s ->
                        val extract = JSONObject(s).optString("extract")
                        if (extract.isNotBlank()) return extract.take(400)
                    }
                }
            }

        // 2) DuckDuckGo الجواب المباشر
        get("https://api.duckduckgo.com/?q=$q&format=json&no_html=1")?.let { body ->
            val j = JSONObject(body)
            val text = j.optString("AbstractText").ifBlank { j.optString("Answer") }
            if (text.isNotBlank()) return text.take(400)
        }
        return "ما لقيت جواب واضح لهالسؤال."
    }
}
