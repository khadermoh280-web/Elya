package com.kabo.app.data

import java.util.Calendar

/** يفكك التسجيل الصوتي لمهام: يقسم الكلام، يستخرج الموعد، ويحدد الأولوية. */
object VoiceTasks {

    private val splitters = Regex(
        "\\s+(?:(?:وبعدين|وبعد هيك|وبعدها|بعدين|ثم|وكمان|وكذلك|و)\\s+)?(?=(?:و\\s*)?(?:بدي|لازم|اذكرني|ذكرني|لا تنسى|ضروري|اتصل|ابعت|روح|جيب|ادفع))"
    )

    private val urgent = listOf("عاجل", "مستعجل", "ضروري", "فورا", "حالا", "اليوم", "اهم شي", "مهم جدا")
    private val medium = listOf("مهم", "لازم", "لا تنسى", "بكرة", "بكره", "غدا")

    /**
     * @param loudness متوسط علو الصوت 0..1، @param wordsPerSec سرعة الكلام. يرفعان الأولوية
     * إذا كان المتحدث متوتر أو مستعجل (تقريب، مش قياس دقيق للمشاعر).
     */
    fun parse(transcript: String, loudness: Float = 0f, wordsPerSec: Float = 0f, now: Long = System.currentTimeMillis()): List<Task> {
        val parts = transcript.trim().split(splitters).filter { it.isNotBlank() }
        return parts.mapIndexed { i, raw ->
            val t = raw.trim()
            var p = when {
                urgent.any { t.contains(it) } -> 3
                medium.any { t.contains(it) } -> 2
                else -> 1
            }
            if (loudness > 0.7f || wordsPerSec > 3.5f) p = minOf(3, p + 1)
            Task(now + i, t, p, dueFrom(t, now), false)
        }
    }

    private fun dueFrom(t: String, now: Long): Long {
        val c = Calendar.getInstance().apply { timeInMillis = now }
        var matched = false

        if (t.contains("بكرة") || t.contains("بكره") || t.contains("غدا")) { c.add(Calendar.DAY_OF_YEAR, 1); matched = true }
        if (t.contains("بعد بكرة") || t.contains("بعد بكره")) { c.add(Calendar.DAY_OF_YEAR, 1) }

        Regex("بعد\\s*(\\d+|ساعة|ساعتين|نص ساعة)\\s*(ساعة|ساعات|دقيقة|دقايق|دقائق)?").find(t)?.let { m ->
            val n = m.groupValues[1]
            val unit = m.groupValues[2]
            val amount = n.toIntOrNull() ?: when (n) { "ساعتين" -> 2; else -> 1 }
            val minutes = when {
                n == "نص ساعة" -> 30
                n == "ساعة" || n == "ساعتين" || unit.startsWith("ساع") -> amount * 60
                else -> amount
            }
            return now + minutes * 60_000L
        }

        Regex("الساعة\\s*(\\d{1,2})(?::(\\d{2}))?").find(t)?.let { m ->
            var h = m.groupValues[1].toInt()
            val min = m.groupValues[2].toIntOrNull() ?: 0
            if (t.contains("مساء") || t.contains("العصر") || t.contains("الليل")) { if (h < 12) h += 12 }
            c.set(Calendar.HOUR_OF_DAY, h); c.set(Calendar.MINUTE, min); c.set(Calendar.SECOND, 0)
            if (!matched && c.timeInMillis <= now) c.add(Calendar.DAY_OF_YEAR, 1)
            return c.timeInMillis
        }

        // بدون موعد: ذكّره بعد ساعة، أو بكرة 9 صباحًا إذا ذكر بكرة
        return if (matched) { c.set(Calendar.HOUR_OF_DAY, 9); c.set(Calendar.MINUTE, 0); c.timeInMillis } else now + 3_600_000L
    }
}
