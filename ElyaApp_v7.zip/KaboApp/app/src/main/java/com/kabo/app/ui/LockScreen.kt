package com.kabo.app.ui

import android.content.Context
import androidx.biometric.BiometricManager
import androidx.biometric.BiometricPrompt
import androidx.compose.animation.core.*
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Fingerprint
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.scale
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.fragment.app.FragmentActivity
import java.security.MessageDigest

object Auth {
    private fun prefs(c: Context) = c.getSharedPreferences("kabo_auth", Context.MODE_PRIVATE)
    private fun hash(pw: String, salt: String) =
        MessageDigest.getInstance("SHA-256").digest((salt + pw).toByteArray()).joinToString("") { "%02x".format(it) }

    fun hasPassword(c: Context) = prefs(c).contains("h")

    fun setPassword(c: Context, pw: String) {
        val salt = System.nanoTime().toString()
        prefs(c).edit().putString("s", salt).putString("h", hash(pw, salt)).apply()
    }

    fun check(c: Context, pw: String): Boolean {
        val p = prefs(c)
        return p.getString("h", null) == hash(pw, p.getString("s", "")!!)
    }

    /** يستخدم بصمة/وجه النظام (فئة قوية) اللي مسجل على الجوال نفسه. */
    fun canBiometric(c: Context) =
        BiometricManager.from(c).canAuthenticate(BiometricManager.Authenticators.BIOMETRIC_STRONG) ==
            BiometricManager.BIOMETRIC_SUCCESS

    fun biometric(a: FragmentActivity, onOk: () -> Unit) {
        val info = BiometricPrompt.PromptInfo.Builder()
            .setTitle("إيليا")
            .setSubtitle("أثبت أنك صاحب الجوال")
            .setNegativeButtonText("استخدم كلمة السر")
            .setAllowedAuthenticators(BiometricManager.Authenticators.BIOMETRIC_STRONG)
            .build()
        BiometricPrompt(a, ContextCompat.getMainExecutor(a), object : BiometricPrompt.AuthenticationCallback() {
            override fun onAuthenticationSucceeded(r: BiometricPrompt.AuthenticationResult) = onOk()
        }).authenticate(info)
    }
}

@Composable
fun LockScreen(activity: FragmentActivity, onUnlocked: () -> Unit) {
    val first = remember { !Auth.hasPassword(activity) }
    var pw by remember { mutableStateOf("") }
    var pw2 by remember { mutableStateOf("") }
    var error by remember { mutableStateOf<String?>(null) }

    LaunchedEffect(Unit) {
        if (!first && Auth.canBiometric(activity)) Auth.biometric(activity, onUnlocked)
    }

    val pulse by rememberInfiniteTransition(label = "p").animateFloat(
        1f, 1.12f, infiniteRepeatable(tween(1400, easing = FastOutSlowInEasing), RepeatMode.Reverse), label = "s"
    )

    AuroraBackground {
        Column(
            Modifier.fillMaxSize().padding(28.dp),
            verticalArrangement = Arrangement.Center,
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Icon(Icons.Default.Lock, null, tint = C.cyan, modifier = Modifier.size(72.dp).scale(pulse))
            Spacer(Modifier.height(18.dp))
            Text("إيليا", fontSize = 40.sp, color = C.text)
            Text(if (first) "اختر كلمة سر للتطبيق" else "أدخل كلمة السر", color = C.dim)
            Spacer(Modifier.height(28.dp))

            Glass(Modifier.fillMaxWidth()) {
                OutlinedTextField(
                    pw, { pw = it; error = null }, label = { Text("كلمة السر") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Password),
                    singleLine = true, modifier = Modifier.fillMaxWidth()
                )
                if (first) {
                    Spacer(Modifier.height(10.dp))
                    OutlinedTextField(
                        pw2, { pw2 = it; error = null }, label = { Text("أعد كتابتها") },
                        visualTransformation = PasswordVisualTransformation(),
                        singleLine = true, modifier = Modifier.fillMaxWidth()
                    )
                }
                error?.let { Text(it, color = C.red, modifier = Modifier.padding(top = 8.dp)) }
                Spacer(Modifier.height(16.dp))
                GradientButton(if (first) "حفظ ودخول" else "دخول", Modifier.fillMaxWidth()) {
                    if (first) {
                        when {
                            pw.length < 4 -> error = "4 خانات على الأقل"
                            pw != pw2 -> error = "كلمتا السر غير متطابقتين"
                            else -> { Auth.setPassword(activity, pw); onUnlocked() }
                        }
                    } else if (Auth.check(activity, pw)) onUnlocked() else error = "كلمة السر غلط"
                }
            }

            if (!first && Auth.canBiometric(activity)) {
                Spacer(Modifier.height(22.dp))
                IconButton(onClick = { Auth.biometric(activity, onUnlocked) }) {
                    Icon(Icons.Default.Fingerprint, "بصمة / وجه", tint = C.violet, modifier = Modifier.size(56.dp))
                }
                Text("بصمة أو وجه الجوال", color = C.dim)
            }
        }
    }
}
