package com.kabo.app.ui

import android.Manifest
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.PowerManager
import android.provider.Settings
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalLifecycleOwner
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.core.content.ContextCompat
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.kabo.app.Gate
import com.kabo.app.assistant.AssistantService
import com.kabo.app.assistant.KaboAccessibilityService
import com.kabo.app.data.Store

@Composable
fun AssistantScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    var wake by remember { mutableStateOf(store.wakeWord) }
    var tick by remember { mutableIntStateOf(0) }
    var running by remember { mutableStateOf(false) }

    // يحدّث حالة الصلاحيات كل ما ترجع من شاشة الإعدادات
    val owner = LocalLifecycleOwner.current
    DisposableEffect(owner) {
        val o = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        owner.lifecycle.addObserver(o); onDispose { owner.lifecycle.removeObserver(o) }
    }

    val mic = ContextCompat.checkSelfPermission(ctx, Manifest.permission.RECORD_AUDIO) == PackageManager.PERMISSION_GRANTED
    val overlay = Settings.canDrawOverlays(ctx)
    val access = tick >= 0 && isAccessibilityOn(ctx)
    val battery = (ctx.getSystemService(PowerManager::class.java)).isIgnoringBatteryOptimizations(ctx.packageName)

    val askMic = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }
    val askNotif = rememberLauncherForActivityResult(ActivityResultContracts.RequestPermission()) { tick++ }

    fun settings(action: String, uri: Uri? = null) {
        Gate.suppress = true
        ctx.startActivity(Intent(action).apply { if (uri != null) data = uri })
    }

    ScreenFrame("المساعد الصوتي", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
            Glass(Modifier.fillMaxWidth()) {
                Text("كلمة التنبيه", color = C.dim)
                OutlinedTextField(wake, { wake = it; store.wakeWord = it.trim().ifBlank { "إيليا" } }, singleLine = true, modifier = Modifier.fillMaxWidth())
                Spacer(Modifier.height(6.dp))
                Text("قول \"$wake\" وبعدها أمرك. مثال: \"$wake افتح واتساب\" أو \"$wake شو عاصمة اليابان\". وكلمة \"صباح الخير\" لحالها بترد عليك.", color = C.dim, fontSize = 12.sp)
            }

            Perm("الميكروفون", mic, "السماح") { askMic.launch(Manifest.permission.RECORD_AUDIO) }
            Perm("الإشعارات (لإبقاء المساعد شغال)", true, "السماح") { askNotif.launch(Manifest.permission.POST_NOTIFICATIONS) }
            Perm("العرض فوق التطبيقات (الفقاعة)", overlay, "فتح الإعدادات") {
                settings(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:${ctx.packageName}"))
            }
            Perm("خدمة الوصول (فتح التطبيقات والتحكم)", access, "فتح الإعدادات") {
                settings(Settings.ACTION_ACCESSIBILITY_SETTINGS)
            }
            Perm("استثناء من توفير البطارية (حتى ما يوقفه النظام)", battery, "فتح الإعدادات") {
                settings(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:${ctx.packageName}"))
            }

            Spacer(Modifier.height(6.dp))
            val ready = mic && overlay
            GradientButton(if (running) "إيقاف المساعد" else "تشغيل المساعد", Modifier.fillMaxWidth()) {
                if (running) { AssistantService.stop(ctx); running = false }
                else if (ready) { AssistantService.start(ctx); running = true }
            }
            if (!ready) Text("فعّل الميكروفون والعرض فوق التطبيقات على الأقل", color = C.amber, fontSize = 13.sp)
            Text("بيستهلك بطارية أكتر لأنه بيسمع باستمرار. بتقدر توقفه من الإشعار الدائم.", color = C.dim, fontSize = 12.sp)
        }
    }
}

private fun isAccessibilityOn(ctx: android.content.Context): Boolean =
    KaboAccessibilityService.isEnabled() ||
        (Settings.Secure.getString(ctx.contentResolver, Settings.Secure.ENABLED_ACCESSIBILITY_SERVICES) ?: "")
            .contains(ctx.packageName)

@Composable
private fun Perm(title: String, ok: Boolean, action: String, onClick: () -> Unit) {
    Glass(Modifier.fillMaxWidth()) {
        Row(verticalAlignment = Alignment.CenterVertically) {
            Text(if (ok) "✓" else "○", color = if (ok) C.green else C.amber, fontSize = 20.sp)
            Spacer(Modifier.width(10.dp))
            Text(title, color = C.text, modifier = Modifier.weight(1f), fontSize = 14.sp)
            if (!ok) TextButton(onClick) { Text(action) }
        }
    }
}
