package com.kabo.app.assistant

import android.accessibilityservice.AccessibilityService
import android.content.Context
import android.content.Intent
import android.hardware.camera2.CameraManager
import android.view.accessibility.AccessibilityEvent

/** يسمح بتنفيذ أوامر النظام: الرجوع، الرئيسية، الإشعارات، فتح التطبيقات. */
class KaboAccessibilityService : AccessibilityService() {

    override fun onServiceConnected() { instance = this }
    override fun onAccessibilityEvent(event: AccessibilityEvent?) {}
    override fun onInterrupt() {}
    override fun onDestroy() { instance = null; super.onDestroy() }

    companion object {
        var instance: KaboAccessibilityService? = null
        private var torchOn = false

        fun isEnabled() = instance != null

        fun home() = instance?.performGlobalAction(GLOBAL_ACTION_HOME) ?: false
        fun back() = instance?.performGlobalAction(GLOBAL_ACTION_BACK) ?: false
        fun recents() = instance?.performGlobalAction(GLOBAL_ACTION_RECENTS) ?: false
        fun notifications() = instance?.performGlobalAction(GLOBAL_ACTION_NOTIFICATIONS) ?: false

        /** يدور على التطبيق باسمه (عربي أو إنجليزي) ويفتحه. */
        fun openApp(ctx: Context, name: String): Boolean {
            val pm = ctx.packageManager
            val wanted = name.trim().lowercase()
            val aliases = mapOf(
                "واتساب" to "whatsapp", "واتس اب" to "whatsapp", "فيسبوك" to "facebook",
                "انستغرام" to "instagram", "انستا" to "instagram", "تلغرام" to "telegram",
                "يوتيوب" to "youtube", "كاميرا" to "camera", "الكاميرا" to "camera",
                "الاعدادات" to "settings", "اعدادات" to "settings", "تيك توك" to "tiktok",
                "كروم" to "chrome", "الخرائط" to "maps", "الساعة" to "clock"
            )
            val key = aliases[wanted] ?: wanted
            val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
            val match = pm.queryIntentActivities(launcher, 0).firstOrNull {
                val label = it.loadLabel(pm).toString().lowercase()
                label.contains(key) || label.contains(wanted) || it.activityInfo.packageName.contains(key)
            } ?: return false
            val intent = pm.getLaunchIntentForPackage(match.activityInfo.packageName) ?: return false
            intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
            ctx.startActivity(intent)
            return true
        }

        fun torch(ctx: Context, on: Boolean): Boolean = try {
            val cm = ctx.getSystemService(Context.CAMERA_SERVICE) as CameraManager
            cm.setTorchMode(cm.cameraIdList.first(), on)
            torchOn = on
            true
        } catch (e: Exception) { false }
    }
}
