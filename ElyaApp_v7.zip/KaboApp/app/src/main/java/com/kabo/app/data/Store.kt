package com.kabo.app.data

import android.content.Context
import org.json.JSONArray
import org.json.JSONObject

data class Txn(val id: Long, val amount: Double, val income: Boolean, val note: String, val time: Long)
data class Task(val id: Long, val text: String, val priority: Int, val due: Long, val done: Boolean)

/** تخزين بسيط محلي على الجوال (SharedPreferences + JSON). */
class Store(ctx: Context) {
    private val p = ctx.getSharedPreferences("kabo_data", Context.MODE_PRIVATE)

    // ---- المصاريف ----
    fun txns(): List<Txn> = read("txns") {
        Txn(it.getLong("id"), it.getDouble("a"), it.getBoolean("in"), it.getString("n"), it.getLong("t"))
    }.sortedByDescending { it.time }

    fun addTxn(t: Txn) = write("txns", txns() + t) {
        JSONObject().put("id", it.id).put("a", it.amount).put("in", it.income).put("n", it.note).put("t", it.time)
    }

    fun deleteTxn(id: Long) = write("txns", txns().filter { it.id != id }) {
        JSONObject().put("id", it.id).put("a", it.amount).put("in", it.income).put("n", it.note).put("t", it.time)
    }

    // ---- المهام ----
    fun tasks(): List<Task> = read("tasks") {
        Task(it.getLong("id"), it.getString("x"), it.getInt("p"), it.getLong("d"), it.getBoolean("f"))
    }

    fun saveTasks(list: List<Task>) = write("tasks", list) {
        JSONObject().put("id", it.id).put("x", it.text).put("p", it.priority).put("d", it.due).put("f", it.done)
    }

    fun addTask(t: Task) = saveTasks(tasks() + t)
    fun setDone(id: Long, done: Boolean) = saveTasks(tasks().map { if (it.id == id) it.copy(done = done) else it })

    // ---- مواضيع الأخبار ----
    fun topics(): List<String> = p.getString("topics", "")!!.split("|").filter { it.isNotBlank() }
    fun saveTopics(l: List<String>) = p.edit().putString("topics", l.joinToString("|")).apply()

    // ---- إعدادات ----
    var wakeWord: String
        get() = p.getString("wake", "إيليا")!!
        set(v) { p.edit().putString("wake", v).apply(); }

    private fun <T> read(key: String, f: (JSONObject) -> T): List<T> {
        val a = JSONArray(p.getString(key, "[]"))
        return (0 until a.length()).map { f(a.getJSONObject(it)) }
    }

    private fun <T> write(key: String, list: List<T>, f: (T) -> JSONObject) {
        p.edit().putString(key, JSONArray(list.map(f)).toString()).apply()
    }
}
