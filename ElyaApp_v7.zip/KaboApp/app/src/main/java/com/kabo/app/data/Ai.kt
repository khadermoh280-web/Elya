package com.kabo.app.data

import android.content.Context
import android.graphics.Bitmap
import android.util.Base64
import okhttp3.MediaType.Companion.toMediaType
import okhttp3.OkHttpClient
import okhttp3.Request
import okhttp3.RequestBody.Companion.toRequestBody
import org.json.JSONArray
import org.json.JSONObject
import java.io.ByteArrayOutputStream
import java.util.concurrent.TimeUnit

data class AiCfg(
    val base: String, val model: String, val vision: String, val key: String,
    val base2: String, val model2: String, val key2: String
)

class AiHttpException(val code: Int, detail: String) : Exception("خطأ من خدمة الذكاء ($code): $detail")

/**
 * عقل إيليا: عميل موحد لأي خدمة نموذج مفتوح متوافقة مع OpenAI
 * (Hugging Face / OpenRouter / Together / Groq / Ollama / vLLM على سيرفرك).
 * فيه إعادة محاولة تلقائية + مزود احتياطي عشان ما يوقف.
 */
object Ai {
    const val DEF_BASE = "https://router.huggingface.co/v1"
    private val client = OkHttpClient.Builder().callTimeout(90, TimeUnit.SECONDS).build()

    fun cfg(ctx: Context): AiCfg {
        val p = ctx.getSharedPreferences("kabo_ai", Context.MODE_PRIVATE)
        return AiCfg(
            p.getString("base", DEF_BASE)!!,
            p.getString("model", "Qwen/Qwen2.5-72B-Instruct")!!,
            p.getString("vision", "Qwen/Qwen2.5-VL-72B-Instruct")!!,
            p.getString("key", "")!!,
            p.getString("base2", "")!!,
            p.getString("model2", "")!!,
            p.getString("key2", "")!!
        )
    }

    fun save(ctx: Context, c: AiCfg) {
        ctx.getSharedPreferences("kabo_ai", Context.MODE_PRIVATE).edit()
            .putString("base", c.base.trim()).putString("model", c.model.trim())
            .putString("vision", c.vision.trim()).putString("key", c.key.trim())
            .putString("base2", c.base2.trim()).putString("model2", c.model2.trim())
            .putString("key2", c.key2.trim()).apply()
    }

    fun configured(ctx: Context): Boolean {
        val c = cfg(ctx)
        return c.key.isNotBlank() || c.base.trim() != DEF_BASE
    }

    fun msg(role: String, content: Any): JSONObject = JSONObject().put("role", role).put("content", content)

    private fun post(base: String, key: String, model: String, messages: JSONArray, maxTokens: Int): String {
        val body = JSONObject().put("model", model).put("temperature", 0.3)
            .put("max_tokens", maxTokens).put("messages", messages)
        val req = Request.Builder().url(base.trim().trimEnd('/') + "/chat/completions")
            .apply { if (key.isNotBlank()) header("Authorization", "Bearer ${key.trim()}") }
            .post(body.toString().toRequestBody("application/json".toMediaType())).build()
        client.newCall(req).execute().use { r ->
            val t = r.body?.string().orEmpty()
            if (!r.isSuccessful) throw AiHttpException(r.code, t.take(200))
            val content = JSONObject(t).getJSONArray("choices").getJSONObject(0).getJSONObject("message").opt("content")
            return ((content as? String) ?: content.toString()).trim()
        }
    }

    /** محادثة كاملة. blocking: استدعيها من خيط خلفي. */
    fun chat(ctx: Context, messages: JSONArray, maxTokens: Int = 1600, vision: Boolean = false): String {
        val c = cfg(ctx)
        val tries = mutableListOf(Triple(c.base, c.key, if (vision && c.vision.isNotBlank()) c.vision else c.model))
        if (!vision && c.base2.isNotBlank() && c.model2.isNotBlank()) tries += Triple(c.base2, c.key2, c.model2)
        var last: Exception? = null
        for ((b, k, m) in tries) {
            var attempt = 0
            while (attempt < 2) {
                try {
                    return post(b, k, m, messages, maxTokens)
                } catch (e: AiHttpException) {
                    last = e
                    if (e.code in 400..499 && e.code != 408 && e.code != 429) break
                } catch (e: Exception) {
                    last = e
                }
                attempt++
                if (attempt < 2) Thread.sleep(1500)
            }
        }
        throw last ?: IllegalStateException("ما في إعداد للذكاء الاصطناعي")
    }

    fun ask(ctx: Context, system: String, user: String, maxTokens: Int = 1600): String =
        chat(ctx, JSONArray().put(msg("system", system)).put(msg("user", user)), maxTokens)

    /** نموذج رؤية: يقرأ صورة ويجاوب عنها. */
    fun vision(
        ctx: Context, bmp: Bitmap, prompt: String, maxTokens: Int = 1200,
        system: String = "أجب بالعربية. صف ما تراه بدقة. لا تحاول تحديد هوية أشخاص حقيقيين من ملامح وجوههم."
    ): String {
        val small = ImageTools.shrink(bmp, 1280)
        val bos = ByteArrayOutputStream()
        small.compress(Bitmap.CompressFormat.JPEG, 85, bos)
        val b64 = Base64.encodeToString(bos.toByteArray(), Base64.NO_WRAP)
        val content = JSONArray()
            .put(JSONObject().put("type", "text").put("text", prompt))
            .put(JSONObject().put("type", "image_url").put("image_url", JSONObject().put("url", "data:image/jpeg;base64,$b64")))
        return chat(ctx, JSONArray().put(msg("system", system)).put(msg("user", content)), maxTokens, vision = true)
    }
}
