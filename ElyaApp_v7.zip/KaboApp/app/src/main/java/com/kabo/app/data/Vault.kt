package com.kabo.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.security.keystore.KeyGenParameterSpec
import android.security.keystore.KeyProperties
import java.io.File
import java.security.KeyStore
import javax.crypto.Cipher
import javax.crypto.KeyGenerator
import javax.crypto.SecretKey
import javax.crypto.spec.GCMParameterSpec

/** خزنة صور مشفرة AES-256-GCM بمفتاح محفوظ داخل Android Keystore (ما بيطلع من الجوال). */
class Vault(private val ctx: Context) {
    private val dir = File(ctx.filesDir, "vault").apply { mkdirs() }

    private fun key(): SecretKey {
        val ks = KeyStore.getInstance("AndroidKeyStore").apply { load(null) }
        (ks.getKey(ALIAS, null) as? SecretKey)?.let { return it }
        val gen = KeyGenerator.getInstance(KeyProperties.KEY_ALGORITHM_AES, "AndroidKeyStore")
        gen.init(
            KeyGenParameterSpec.Builder(ALIAS, KeyProperties.PURPOSE_ENCRYPT or KeyProperties.PURPOSE_DECRYPT)
                .setBlockModes(KeyProperties.BLOCK_MODE_GCM)
                .setEncryptionPaddings(KeyProperties.ENCRYPTION_PADDING_NONE)
                .setKeySize(256)
                .build()
        )
        return gen.generateKey()
    }

    fun add(bytes: ByteArray): String {
        val name = "${System.currentTimeMillis()}.enc"
        val c = Cipher.getInstance("AES/GCM/NoPadding").apply { init(Cipher.ENCRYPT_MODE, key()) }
        File(dir, name).writeBytes(c.iv + c.doFinal(bytes))
        return name
    }

    fun list(): List<String> = dir.listFiles()?.map { it.name }?.sortedDescending() ?: emptyList()

    fun load(name: String): Bitmap? = try {
        val all = File(dir, name).readBytes()
        val c = Cipher.getInstance("AES/GCM/NoPadding")
            .apply { init(Cipher.DECRYPT_MODE, key(), GCMParameterSpec(128, all.copyOfRange(0, 12))) }
        val plain = c.doFinal(all, 12, all.size - 12)
        BitmapFactory.decodeByteArray(plain, 0, plain.size)
    } catch (e: Exception) { null }

    fun delete(name: String) { File(dir, name).delete() }

    companion object { private const val ALIAS = "kabo_vault_key" }
}
