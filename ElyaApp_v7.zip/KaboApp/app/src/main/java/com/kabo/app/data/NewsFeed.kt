package com.kabo.app.data

import android.util.Xml
import okhttp3.OkHttpClient
import okhttp3.Request
import org.xmlpull.v1.XmlPullParser
import java.net.URLEncoder

data class NewsItem(val title: String, val source: String, val link: String, val date: String)

/** أخبار محدثة حسب الموضوع من Google News RSS (مصادر متعددة من وكالات وصحف). */
object NewsFeed {
    private val client = OkHttpClient()

    fun fetch(topic: String, limit: Int = 8): List<NewsItem> {
        val q = URLEncoder.encode(topic, "UTF-8")
        val url = "https://news.google.com/rss/search?q=$q&hl=ar&gl=PS&ceid=PS:ar"
        val body = try {
            client.newCall(Request.Builder().url(url).header("User-Agent", "KaboApp/1.0").build())
                .execute().use { it.body?.byteStream()?.readBytes() }
        } catch (e: Exception) { null } ?: return emptyList()

        val p = Xml.newPullParser().apply { setInput(body.inputStream(), "UTF-8") }
        val out = mutableListOf<NewsItem>()
        var title = ""; var link = ""; var date = ""; var source = ""
        var inItem = false
        var tag = ""
        while (p.next() != XmlPullParser.END_DOCUMENT && out.size < limit) {
            when (p.eventType) {
                XmlPullParser.START_TAG -> { tag = p.name; if (tag == "item") { inItem = true; title = ""; link = ""; date = ""; source = "" } }
                XmlPullParser.TEXT -> if (inItem) when (tag) {
                    "title" -> title += p.text
                    "link" -> link += p.text
                    "pubDate" -> date += p.text
                    "source" -> source += p.text
                }
                XmlPullParser.END_TAG -> {
                    if (p.name == "item") { out += NewsItem(title.trim(), source.trim(), link.trim(), date.trim().take(22)); inItem = false }
                    tag = ""
                }
            }
        }
        return out
    }
}
