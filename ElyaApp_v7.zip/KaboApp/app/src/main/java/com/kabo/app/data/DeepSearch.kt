package com.kabo.app.data

import android.content.Context
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.async
import kotlinx.coroutines.awaitAll
import kotlinx.coroutines.coroutineScope
import kotlinx.coroutines.runBlocking
import kotlinx.coroutines.withContext
import okhttp3.OkHttpClient
import okhttp3.Request
import java.net.URLDecoder
import java.net.URLEncoder
import java.util.concurrent.TimeUnit

data class Source(val title: String, val url: String, val text: String)
data class DeepResult(val answer: String, val sources: List<Source>)

/**
 * بحث عميق على جولتين: النموذج يولّد استعلامات → بحث بالنت + أخبار → قراءة الصفحات →
 * النموذج يكتشف النقص ويبحث جولة ثانية → جواب نهائي مع أرقام المصادر.
 */
object DeepSearch {
    private val fast = OkHttpClient.Builder().callTimeout(15, TimeUnit.SECONDS).build()
    private const val UA = "Mozilla/5.0 (Linux; Android 14) AppleWebKit/537.36 Chrome/124 Mobile Safari/537.36"

    private fun ddg(q: String): List<Pair<String, String>> {
        val html = try {
            fast.newCall(Request.Builder().url("https://html.duckduckgo.com/html/?q=" + URLEncoder.encode(q, "UTF-8")).header("User-Agent", UA).build())
                .execute().use { it.body?.string() }
        } catch (e: Exception) { null } ?: return emptyList()
        val re = Regex("""class="result__a"[^>]*href="([^"]+)"[^>]*>(.*?)</a>""", RegexOption.DOT_MATCHES_ALL)
        return re.findAll(html).mapNotNull { m ->
            var u = m.groupValues[1].replace("&amp;", "&")
            Regex("""uddg=([^&]+)""").find(u)?.let { u = URLDecoder.decode(it.groupValues[1], "UTF-8") }
            if (!u.startsWith("http")) return@mapNotNull null
            u to clean(m.groupValues[2])
        }.toList()
    }

    private fun clean(h: String): String = h
        .replace(Regex("(?is)<(script|style|noscript|svg|header|footer|nav)[^>]*>.*?</\\1>"), " ")
        .replace(Regex("(?s)<[^>]+>"), " ")
        .replace("&nbsp;", " ").replace("&amp;", "&").replace("&quot;", "\"").replace("&#39;", "'")
        .replace(Regex("\\s+"), " ").trim()

    private fun page(url: String): String? = try {
        fast.newCall(Request.Builder().url(url).header("User-Agent", UA).build()).execute().use { r ->
            val ct = r.header("Content-Type").orEmpty()
            if (!r.isSuccessful || !ct.contains("html")) null else clean(r.body!!.source().readUtf8().take(400_000)).take(3500)
        }
    } catch (e: Exception) { null }

    private fun lines(s: String): List<String> =
        s.lines().map { it.trim().trim('-', '*', '"', '•') }.filter { it.isNotBlank() }

    /** جواب سريع قصير (للمساعد الصوتي). blocking. */
    fun quick(ctx: Context, q: String): String {
        val found = ddg(q).take(4)
        val pages = runBlocking(Dispatchers.IO) {
            coroutineScope { found.map { (u, t) -> async { page(u)?.let { Source(t, u, it.take(2000)) } } }.awaitAll() }.filterNotNull()
        }
        val news = NewsFeed.fetch(q, 4)
        val ctxText = pages.mapIndexed { i, s -> "[${i + 1}] ${s.title}\n${s.text}" }.joinToString("\n\n") +
            if (news.isNotEmpty()) "\n\nأخبار:\n" + news.joinToString("\n") { "- ${it.title} (${it.source})" } else ""
        if (ctxText.isBlank()) return "ما لقيت نتائج بالنت لهالسؤال."
        return Ai.ask(ctx,
            "أجب بالعربية بجملتين أو ثلاث فقط، بأسلوب مناسب للقراءة بصوت عالي، اعتمادًا على المصادر. إذا ما لقيت الجواب قل ذلك.",
            "السؤال: $q\n\n$ctxText", 350)
    }

    suspend fun run(ctx: Context, question: String, status: (String) -> Unit): DeepResult = withContext(Dispatchers.IO) {
        require(Ai.configured(ctx)) { "ما في إعداد للذكاء الاصطناعي. افتح (إعدادات الذكاء) من الشاشة الرئيسية وحط التوكن." }

        status("عم أحضّر استعلامات البحث...")
        val queries = (try {
            lines(Ai.ask(ctx,
                "أنت خبير بحث. اكتب 3 استعلامات بحث قصيرة ومختلفة (واحد عربي وواحد إنجليزي على الأقل) تغطي السؤال. سطر لكل استعلام بدون ترقيم أو شرح.",
                question, 150)).take(3)
        } catch (e: Exception) { emptyList<String>() }).ifEmpty { listOf(question) }

        status("عم أبحث بالنت...")
        val found = coroutineScope { queries.map { async { ddg(it) } }.awaitAll() }.flatten().distinctBy { it.first }.take(8)

        status("عم أقرأ ${found.size} صفحة...")
        val pages = coroutineScope { found.map { (u, t) -> async { page(u)?.let { Source(t, u, it) } } }.awaitAll() }
            .filterNotNull().toMutableList()

        // جولة ثانية: يكتشف النقص
        if (pages.isNotEmpty()) {
            status("عم أتأكد إذا في نقص بالمعلومات...")
            val gaps = try {
                lines(Ai.ask(ctx,
                    "أنت باحث. بناءً على سؤال المستخدم ومقتطفات المصادر، إذا المعلومات ناقصة أو تحتاج تحقق اكتب حتى استعلامين بحث إضافيين (سطر لكل استعلام). إذا كافية اكتب كلمة واحدة: كافي.",
                    "السؤال: $question\n\n" + pages.joinToString("\n") { "- ${it.title}: ${it.text.take(300)}" }, 120))
                    .filter { !it.contains("كافي") }.take(2)
            } catch (e: Exception) { emptyList<String>() }
            if (gaps.isNotEmpty()) {
                status("عم أعمّق البحث بجولة ثانية...")
                val seen = pages.map { it.url }.toSet()
                val more = coroutineScope { gaps.map { async { ddg(it) } }.awaitAll() }.flatten()
                    .filter { it.first !in seen }.distinctBy { it.first }.take(4)
                pages += coroutineScope { more.map { (u, t) -> async { page(u)?.let { Source(t, u, it) } } }.awaitAll() }.filterNotNull()
            }
        }

        val news = NewsFeed.fetch(question, 6)
        if (news.isNotEmpty()) pages += Source("أخبار حديثة", news.first().link,
            news.joinToString("\n") { "- ${it.title} (${it.source}، ${it.date})" })
        require(pages.isNotEmpty()) { "ما لقيت نتائج. تأكد من النت وجرب صياغة ثانية." }

        status("الذكاء الاصطناعي عم يحلل المصادر ويكتب الجواب...")
        val ctxText = pages.mapIndexed { i, s -> "[${i + 1}] ${s.title} — ${s.url}\n${s.text}" }.joinToString("\n\n")
        val answer = Ai.ask(ctx,
            "أنت باحث دقيق. أجب بالعربية فقط اعتمادًا على المصادر المرفقة. ضع رقم المصدر [n] بعد كل معلومة. " +
            "إذا تعارضت المصادر أو نقصت المعلومات قل ذلك بوضوح ولا تخمّن. لا تذكر معلومات خاصة عن أفراد عاديين (عنوان، هاتف، تفاصيل عائلية). " +
            "رتّب الجواب بعناوين قصيرة ونقاط.",
            "السؤال: $question\n\nالمصادر:\n$ctxText", 2000)
        DeepResult(answer, pages)
    }
}
