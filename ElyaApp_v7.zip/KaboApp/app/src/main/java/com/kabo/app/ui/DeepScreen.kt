package com.kabo.app.ui

import android.content.Intent
import android.net.Uri
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kabo.app.Gate
import com.kabo.app.data.DeepResult
import com.kabo.app.data.DeepSearch
import kotlinx.coroutines.launch

@Composable
fun DeepScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var q by remember { mutableStateOf("") }
    var status by remember { mutableStateOf<String?>(null) }
    var err by remember { mutableStateOf("") }
    var res by remember { mutableStateOf<DeepResult?>(null) }

    fun open(url: String) { Gate.suppress = true; ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(url)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)) }

    ScreenFrame("بحث عميق", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            OutlinedTextField(q, { q = it }, label = { Text("شو بدك تعرف؟ (شخص، موضوع، سؤال)") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(10.dp))
            GradientButton("ابحث بعمق", Modifier.fillMaxWidth()) {
                if (q.isBlank() || status != null) return@GradientButton
                err = ""; res = null; status = "بدأت..."
                scope.launch {
                    try { res = DeepSearch.run(ctx, q.trim()) { status = it } }
                    catch (e: Throwable) { err = e.message ?: "خطأ غير معروف" }
                    status = null
                }
            }
            Text("الإعدادات: الشاشة الرئيسية ← إعدادات الذكاء", color = C.dim, fontSize = 12.sp, modifier = Modifier.padding(top = 6.dp))
            status?.let { Spacer(Modifier.height(10.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()); Text(it, color = C.dim, fontSize = 13.sp) }
            if (err.isNotBlank()) Text(err, color = C.amber, modifier = Modifier.padding(top = 8.dp))

            res?.let { r ->
                Spacer(Modifier.height(14.dp))
                Glass(Modifier.fillMaxWidth()) { SelectionContainer { Text(r.answer, color = C.text, fontSize = 15.sp) } }
                Spacer(Modifier.height(12.dp))
                Text("المصادر", color = C.text, fontSize = 18.sp)
                r.sources.forEachIndexed { i, s ->
                    TextButton(onClick = { open(s.url) }) { Text("[${i + 1}] ${s.title.take(60)}", color = C.cyan) }
                }
            }
        }
    }
}
