package com.kabo.app.assistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Color
import android.graphics.PixelFormat
import android.graphics.drawable.GradientDrawable
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.speech.tts.TextToSpeech
import android.view.Gravity
import android.view.WindowManager
import android.widget.TextView
import java.util.Locale
import java.util.concurrent.Executors

/**
 * خدمة أمامية: تسمع باستمرار، وإذا سمعت كلمة التنبيه تنفذ الأمر
 * وترد بفقاعة صغيرة عائمة فوق كل التطبيقات وبصوت.
 */
class AssistantService : Service() {

    private val main = Handler(Looper.getMainLooper())
    private val worker = Executors.newSingleThreadExecutor()
    private var recognizer: SpeechRecognizer? = null
    private var tts: TextToSpeech? = null
    private var bubble: TextView? = null
    private var waitingForCommand = false
    private var running = false

    private val wakeWord: String
        get() = com.kabo.app.data.Store(this).wakeWord

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onCreate() {
        super.onCreate()
        tts = TextToSpeech(this) { if (it == TextToSpeech.SUCCESS) tts?.language = Locale("ar") }
        startAsForeground()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        if (!running) {
            running = true
            main.post { listen() }
        }
        return START_STICKY
    }

    private fun startAsForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "المساعد", NotificationManager.IMPORTANCE_LOW)
        )
        val stop = android.app.PendingIntent.getService(
            this, 0, Intent(this, AssistantService::class.java).setAction(ACTION_STOP),
            android.app.PendingIntent.FLAG_IMMUTABLE
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("إيليا شغّال")
            .setContentText("قول \"$wakeWord\" وبعدها أمرك")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .addAction(Notification.Action.Builder(android.R.drawable.ic_media_pause, "إيقاف", stop).build())
            .setOngoing(true)
            .build()
        startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
    }

    // ---------- الاستماع ----------

    private fun listen() {
        if (!running) return
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(object : RecognitionListener {
                override fun onResults(results: Bundle?) {
                    val text = results?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                        ?.firstOrNull().orEmpty()
                    if (text.isNotBlank()) onHeard(text)
                    restart()
                }
                override fun onError(error: Int) = restart(if (error == SpeechRecognizer.ERROR_RECOGNIZER_BUSY) 1500 else 400)
                override fun onReadyForSpeech(p: Bundle?) {}
                override fun onBeginningOfSpeech() {}
                override fun onRmsChanged(rmsdB: Float) {}
                override fun onBufferReceived(b: ByteArray?) {}
                override fun onEndOfSpeech() {}
                override fun onPartialResults(p: Bundle?) {}
                override fun onEvent(t: Int, p: Bundle?) {}
            })
            startListening(
                Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
                    .putExtra(RecognizerIntent.EXTRA_LANGUAGE, "ar-PS")
                    .putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, false)
            )
        }
    }

    private fun restart(delay: Long = 300) { if (running) main.postDelayed({ listen() }, delay) }

    private fun onHeard(heard: String) {
        val t = CommandRouter.normalize(heard)
        val wake = CommandRouter.normalize(wakeWord)
        val isGreeting = t.contains("صباح الخير") || t.contains("مساء الخير")
        val hasWake = t.contains(wake)

        if (!hasWake && !waitingForCommand && !isGreeting) return

        val command = t.replace(wake, "").trim()
        if (command.isBlank()) {
            waitingForCommand = true
            reply("نعم؟")
            return
        }
        waitingForCommand = false
        show("...")
        worker.execute {
            val answer = try { CommandRouter.handle(applicationContext, command) }
            catch (e: Exception) { "صار خطأ، جرب مرة ثانية" }
            main.post { reply(answer) }
        }
    }

    // ---------- الرد ----------

    private fun reply(text: String) {
        show(text)
        tts?.speak(text, TextToSpeech.QUEUE_FLUSH, null, "kabo")
    }

    private fun show(text: String) {
        if (!android.provider.Settings.canDrawOverlays(this)) return
        val wm = getSystemService(Context.WINDOW_SERVICE) as WindowManager
        if (bubble == null) {
            bubble = TextView(this).apply {
                setTextColor(Color.WHITE)
                textSize = 15f
                setPadding(44, 26, 44, 26)
                maxWidth = resources.displayMetrics.widthPixels - 120
                background = GradientDrawable().apply {
                    cornerRadius = 70f
                    setColor(Color.parseColor("#E6141428"))
                    setStroke(3, Color.parseColor("#8B5CF6"))
                }
            }
            val lp = WindowManager.LayoutParams(
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.WRAP_CONTENT,
                WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE or WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE,
                PixelFormat.TRANSLUCENT
            ).apply { gravity = Gravity.TOP or Gravity.CENTER_HORIZONTAL; y = 110 }
            wm.addView(bubble, lp)
        }
        bubble?.text = text
        main.removeCallbacks(hide)
        main.postDelayed(hide, 6000)
    }

    private val hide = Runnable {
        bubble?.let { (getSystemService(Context.WINDOW_SERVICE) as WindowManager).removeView(it) }
        bubble = null
    }

    override fun onDestroy() {
        running = false
        main.removeCallbacksAndMessages(null)
        hide.run()
        recognizer?.destroy()
        tts?.shutdown()
        worker.shutdownNow()
        super.onDestroy()
    }

    companion object {
        const val CHANNEL = "kabo_assistant"
        const val ACTION_STOP = "com.kabo.app.STOP"

        fun start(ctx: Context) =
            ctx.startForegroundService(Intent(ctx, AssistantService::class.java))
        fun stop(ctx: Context) =
            ctx.startService(Intent(ctx, AssistantService::class.java).setAction(ACTION_STOP))
    }
}
