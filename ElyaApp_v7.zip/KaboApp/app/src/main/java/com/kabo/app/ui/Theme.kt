package com.kabo.app.ui

import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.drawBehind
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalLayoutDirection
import androidx.compose.ui.unit.LayoutDirection
import androidx.compose.ui.unit.dp

object C {
    val bg = Color(0xFF07070F)
    val violet = Color(0xFF8B5CF6)
    val cyan = Color(0xFF22D3EE)
    val pink = Color(0xFFF472B6)
    val green = Color(0xFF34D399)
    val red = Color(0xFFFB7185)
    val amber = Color(0xFFFBBF24)
    val glass = Color(0x1AFFFFFF)
    val glassBorder = Color(0x33FFFFFF)
    val text = Color(0xFFF4F4FA)
    val dim = Color(0xFFA1A1B5)
}

@Composable
fun KaboTheme(content: @Composable () -> Unit) {
    CompositionLocalProvider(LocalLayoutDirection provides LayoutDirection.Rtl) {
        MaterialTheme(
            colorScheme = darkColorScheme(
                primary = C.violet, secondary = C.cyan, background = C.bg, surface = C.bg,
                onPrimary = Color.White, onBackground = C.text, onSurface = C.text
            ),
            content = content
        )
    }
}

/** خلفية "شفق" متحركة: كرات ضوئية بطيئة الحركة فوق أسود عميق. */
@Composable
fun AuroraBackground(content: @Composable BoxScope.() -> Unit) {
    val t = rememberInfiniteTransition(label = "aurora")
    val a by t.animateFloat(0f, 1f, infiniteRepeatable(tween(14000, easing = LinearEasing), RepeatMode.Reverse), label = "a")
    val b by t.animateFloat(1f, 0f, infiniteRepeatable(tween(19000, easing = LinearEasing), RepeatMode.Reverse), label = "b")
    Box(
        Modifier
            .fillMaxSize()
            .background(C.bg)
            .drawBehind {
                val w = size.width; val h = size.height
                drawRect(Brush.radialGradient(listOf(C.violet.copy(alpha = .42f), Color.Transparent),
                    Offset(w * (.15f + .6f * a), h * (.10f + .25f * b)), w * .75f))
                drawRect(Brush.radialGradient(listOf(C.cyan.copy(alpha = .28f), Color.Transparent),
                    Offset(w * (.9f - .6f * b), h * (.55f + .2f * a)), w * .7f))
                drawRect(Brush.radialGradient(listOf(C.pink.copy(alpha = .22f), Color.Transparent),
                    Offset(w * (.3f + .3f * a), h * (.95f - .25f * b)), w * .65f))
            },
        content = content
    )
}

/** بطاقة زجاجية بحدود لامعة. */
@Composable
fun Glass(modifier: Modifier = Modifier, content: @Composable ColumnScope.() -> Unit) {
    Column(
        modifier
            .background(C.glass, RoundedCornerShape(26.dp))
            .border(1.dp, Brush.linearGradient(listOf(C.glassBorder, Color(0x08FFFFFF))), RoundedCornerShape(26.dp))
            .padding(18.dp),
        content = content
    )
}

@Composable
fun GradientButton(text: String, modifier: Modifier = Modifier, onClick: () -> Unit) {
    Box(
        modifier
            .background(Brush.horizontalGradient(listOf(C.violet, C.cyan)), RoundedCornerShape(18.dp))
            .clickableNoRipple(onClick)
            .padding(horizontal = 22.dp, vertical = 14.dp),
        contentAlignment = Alignment.Center
    ) { Text(text, color = Color.White) }
}

@Composable
fun Modifier.clickableNoRipple(onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = remember { MutableInteractionSource() },
        indication = null,
        onClick = onClick
    )
