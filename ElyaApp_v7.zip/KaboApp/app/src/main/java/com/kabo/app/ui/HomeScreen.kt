package com.kabo.app.ui

import androidx.compose.animation.*
import androidx.compose.animation.core.*
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.alpha
import androidx.compose.ui.draw.scale
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kabo.app.Screen
import com.kabo.app.data.Store
import kotlinx.coroutines.delay
import java.util.Calendar

private data class Tile(val screen: Screen, val title: String, val sub: String, val icon: ImageVector, val c1: Color, val c2: Color)

private val tiles = listOf(
    Tile(Screen.ASSISTANT, "المساعد الصوتي", "فقاعة عائمة", Icons.Default.Mic, C.violet, C.pink),
    Tile(Screen.MONEY, "المصاريف", "دخل وجرد وتقرير", Icons.Default.AccountBalanceWallet, C.green, C.cyan),
    Tile(Screen.TASKS, "مهامي الصوتية", "سجّل وأنا أرتب", Icons.Default.NotificationsActive, C.amber, C.pink),
    Tile(Screen.VAULT, "الخزنة", "صور مشفرة", Icons.Default.Lock, C.cyan, C.violet),
    Tile(Screen.PHOTO, "أدوات الصور", "ترميم AI + PDF", Icons.Default.AutoFixHigh, C.pink, C.violet),
    Tile(Screen.BOOK, "كتبي", "اسأل كتابك", Icons.Default.MenuBook, C.amber, C.cyan),
    Tile(Screen.AISET, "إعدادات الذكاء", "النموذج والسيرفر", Icons.Default.Psychology, C.pink, C.violet),
    Tile(Screen.DEEP, "بحث عميق", "نت + ذكاء مفتوح", Icons.Default.TravelExplore, C.green, C.violet),
    Tile(Screen.PEOPLE, "بحث عن مشهور", "حسابات وصور رسمية", Icons.Default.PersonSearch, C.violet, C.cyan),
    Tile(Screen.NEWS, "الأخبار", "حسب اهتمامك", Icons.Default.Newspaper, C.cyan, C.green),
)

@Composable
fun HomeScreen(go: (Screen) -> Unit) {
    val ctx = LocalContext.current
    val store = remember { Store(ctx) }
    val month = remember {
        val c = Calendar.getInstance().apply { set(Calendar.DAY_OF_MONTH, 1); set(Calendar.HOUR_OF_DAY, 0); set(Calendar.MINUTE, 0) }
        store.txns().filter { it.time >= c.timeInMillis }
    }
    val income = month.filter { it.income }.sumOf { it.amount }
    val spent = month.filter { !it.income }.sumOf { it.amount }
    val hour = remember { Calendar.getInstance().get(Calendar.HOUR_OF_DAY) }
    val hello = if (hour < 12) "صباح الخير" else if (hour < 18) "نهارك سعيد" else "مساء الخير"

    Column(Modifier.fillMaxSize().padding(horizontal = 20.dp).statusBarsPadding()) {
        Spacer(Modifier.height(24.dp))
        Text(hello, color = C.dim, fontSize = 16.sp)
        Text("إيليا", color = C.text, fontSize = 44.sp)
        Spacer(Modifier.height(18.dp))

        Glass(Modifier.fillMaxWidth()) {
            Text("رصيد هذا الشهر", color = C.dim)
            Text("%,.2f".format(income - spent), color = if (income >= spent) C.green else C.red, fontSize = 34.sp)
            Spacer(Modifier.height(6.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(24.dp)) {
                Text("دخل  %,.0f".format(income), color = C.green)
                Text("صرف  %,.0f".format(spent), color = C.red)
            }
        }
        Spacer(Modifier.height(18.dp))

        LazyVerticalGrid(
            GridCells.Fixed(2),
            horizontalArrangement = Arrangement.spacedBy(14.dp),
            verticalArrangement = Arrangement.spacedBy(14.dp),
            contentPadding = PaddingValues(bottom = 24.dp)
        ) {
            items(tiles.size) { i -> AnimatedTile(tiles[i], i) { go(tiles[i].screen) } }
        }
    }
}

@Composable
private fun AnimatedTile(t: Tile, index: Int, onClick: () -> Unit) {
    var shown by remember { mutableStateOf(false) }
    LaunchedEffect(Unit) { delay(80L * index); shown = true }
    val a by animateFloatAsState(if (shown) 1f else 0f, tween(500), label = "a")
    val s by animateFloatAsState(if (shown) 1f else .85f, spring(dampingRatio = .55f), label = "s")

    Box(
        Modifier
            .alpha(a).scale(s)
            .fillMaxWidth().aspectRatio(1f)
            .background(Brush.linearGradient(listOf(t.c1.copy(alpha = .35f), t.c2.copy(alpha = .12f))), RoundedCornerShape(28.dp))
            .clickableNoRipple(onClick)
            .padding(18.dp)
    ) {
        Icon(t.icon, null, tint = Color.White, modifier = Modifier.size(38.dp).align(Alignment.TopStart))
        Column(Modifier.align(Alignment.BottomStart)) {
            Text(t.title, color = C.text, fontSize = 18.sp)
            Text(t.sub, color = C.dim, fontSize = 12.sp)
        }
    }
}
