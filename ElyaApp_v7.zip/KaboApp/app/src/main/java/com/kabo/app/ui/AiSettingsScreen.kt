package com.kabo.app.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kabo.app.data.Ai
import com.kabo.app.data.AiCfg
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun AiSettingsScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    val c0 = remember { Ai.cfg(ctx) }
    var base by remember { mutableStateOf(c0.base) }
    var model by remember { mutableStateOf(c0.model) }
    var vision by remember { mutableStateOf(c0.vision) }
    var key by remember { mutableStateOf(c0.key) }
    var base2 by remember { mutableStateOf(c0.base2) }
    var model2 by remember { mutableStateOf(c0.model2) }
    var key2 by remember { mutableStateOf(c0.key2) }
    var result by remember { mutableStateOf("") }
    var testing by remember { mutableStateOf(false) }

    fun save() = Ai.save(ctx, AiCfg(base, model, vision, key, base2, model2, key2))

    ScreenFrame("إعدادات الذكاء", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            Glass(Modifier.fillMaxWidth()) {
                Text("عقل إيليا", color = C.text, fontSize = 18.sp)
                Text("أي خدمة متوافقة مع OpenAI تشتغل. اختر قالب جاهز وحط التوكن. إذا اسم نموذج تغيّر عند المزوّد، عدّله هون.", color = C.dim, fontSize = 12.sp)
                Row {
                    TextButton(onClick = { base = Ai.DEF_BASE; model = "Qwen/Qwen2.5-72B-Instruct"; vision = "Qwen/Qwen2.5-VL-72B-Instruct" }) { Text("HuggingFace") }
                    TextButton(onClick = { base = "https://openrouter.ai/api/v1"; model = "qwen/qwen-2.5-72b-instruct"; vision = "qwen/qwen2.5-vl-72b-instruct" }) { Text("OpenRouter") }
                    TextButton(onClick = { base = "http://192.168.1.10:11434/v1"; model = "qwen2.5:72b"; vision = "qwen2.5vl" }) { Text("سيرفري (Ollama)") }
                }
                OutlinedTextField(base, { base = it }, label = { Text("العنوان (Base URL)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(model, { model = it }, label = { Text("نموذج النص") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(vision, { vision = it }, label = { Text("نموذج الصور (رؤية)") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(key, { key = it }, label = { Text("التوكن / API Key") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(12.dp))
            Glass(Modifier.fillMaxWidth()) {
                Text("مزوّد احتياطي (اختياري)", color = C.text, fontSize = 18.sp)
                Text("إذا الأساسي وقع أو انحجب، التطبيق بيتحول تلقائيًا للاحتياطي. هيك ما بيوقف.", color = C.dim, fontSize = 12.sp)
                OutlinedTextField(base2, { base2 = it }, label = { Text("العنوان") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(model2, { model2 = it }, label = { Text("النموذج") }, singleLine = true, modifier = Modifier.fillMaxWidth())
                OutlinedTextField(key2, { key2 = it }, label = { Text("التوكن") }, singleLine = true, modifier = Modifier.fillMaxWidth())
            }
            Spacer(Modifier.height(12.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GradientButton("حفظ", Modifier.weight(1f)) { save(); result = "انحفظ" }
                GradientButton("جرّب الاتصال", Modifier.weight(1f)) {
                    if (testing) return@GradientButton
                    save(); testing = true; result = "عم أجرب..."
                    scope.launch {
                        result = try {
                            "اشتغل ✓ الرد: " + withContext(Dispatchers.IO) { Ai.ask(ctx, "أجب بجملة قصيرة بالعربية.", "قل: أنا جاهز", 40) }
                        } catch (e: Throwable) { "فشل: ${e.message}" }
                        testing = false
                    }
                }
            }
            if (result.isNotBlank()) Text(result, color = C.amber, modifier = Modifier.padding(top = 10.dp))
        }
    }
}
