package com.kabo.app.assistant

import android.content.Context
import android.content.Intent
import android.net.Uri
import com.kabo.app.data.Ai
import com.kabo.app.data.DeepSearch
import org.json.JSONArray
import org.json.JSONObject
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

/** عقل المساعد الصوتي: النموذج يقرر يجاوب أو ينفذ أمر أو يبحث بالنت. */
object Brain {
    private val history = mutableListOf<Pair<String, String>>()

    private fun system(): String {
        val d = SimpleDateFormat("EEEE d MMMM yyyy HH:mm", Locale("ar")).format(Date())
        return """أنت "إيليا"، مساعد صوتي ذكي على جوال أندرويد. الوقت الآن: $d.
تكلم بلهجة عربية بسيطة وجمل قصيرة مناسبة للقراءة بصوت عالي.
ردّ دائمًا بكائن JSON واحد فقط بدون أي نص خارجه، من هذه الأشكال:
{"say":"جوابك المباشر"}  للأسئلة اللي بتعرف جوابها.
{"action":"search","arg":"استعلام بحث"}  لما يحتاج السؤال معلومات حديثة أو أرقام أو أخبار أو ما أنت متأكد منها.
{"action":"open_app","arg":"اسم التطبيق"}
{"action":"torch","arg":"on"}  أو "off"
{"action":"home"}  {"action":"back"}  {"action":"notifications"}  {"action":"recents"}
{"action":"open_url","arg":"https://..."}  لفتح موقع.
إذا طلب المستخدم شي ما بتقدر تنفذه قل بصدق ما بقدر عبر {"say":"..."} واقترح بديل."""
    }

    private fun access(f: () -> Boolean): String =
        if (!KaboAccessibilityService.isEnabled()) "فعّل صلاحية الوصول لإيليا من الإعدادات أول"
        else if (f()) "تم" else "ما قدرت أنفذ"

    @Synchronized
    fun respond(ctx: Context, text: String): String {
        val msgs = JSONArray().put(Ai.msg("system", system()))
        history.takeLast(8).forEach { (u, a) ->
            msgs.put(Ai.msg("user", u)); msgs.put(Ai.msg("assistant", JSONObject().put("say", a).toString()))
        }
        msgs.put(Ai.msg("user", text))
        val out = Ai.chat(ctx, msgs, 500)
        val reply = execute(ctx, out)
        history += text to reply
        if (history.size > 20) history.removeAt(0)
        return reply
    }

    private fun execute(ctx: Context, out: String): String {
        val s = out.indexOf('{'); val e = out.lastIndexOf('}')
        val j = try { if (s >= 0 && e > s) JSONObject(out.substring(s, e + 1)) else null } catch (ex: Exception) { null }
            ?: return out.take(500)
        val arg = j.optString("arg")
        return when (j.optString("action")) {
            "" -> j.optString("say").ifBlank { out.take(500) }
            "open_app" -> if (KaboAccessibilityService.openApp(ctx, arg)) "فتحت $arg" else "ما لقيت تطبيق اسمه $arg"
            "torch" -> if (KaboAccessibilityService.torch(ctx, arg != "off")) (if (arg != "off") "شغلت الكشاف" else "طفيت الكشاف") else "ما قدرت أتحكم بالكشاف"
            "home" -> access { KaboAccessibilityService.home() }
            "back" -> access { KaboAccessibilityService.back() }
            "notifications" -> access { KaboAccessibilityService.notifications() }
            "recents" -> access { KaboAccessibilityService.recents() }
            "search" -> DeepSearch.quick(ctx, arg.ifBlank { "" })
            "open_url" -> try {
                ctx.startActivity(Intent(Intent.ACTION_VIEW, Uri.parse(arg)).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)); "فتحت الموقع"
            } catch (ex: Exception) { "ما قدرت أفتح الرابط" }
            else -> j.optString("say").ifBlank { "ما فهمت الأمر" }
        }
    }
}
