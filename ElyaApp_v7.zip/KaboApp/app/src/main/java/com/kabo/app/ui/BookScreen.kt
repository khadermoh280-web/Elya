package com.kabo.app.ui

import android.graphics.BitmapFactory
import android.net.Uri
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.text.selection.SelectionContainer
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kabo.app.Gate
import com.kabo.app.data.Ai
import com.kabo.app.data.Books
import com.kabo.app.data.ImageTools
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext

@Composable
fun BookScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val scope = rememberCoroutineScope()
    var library by remember { mutableStateOf(Books.list(ctx)) }
    var current by remember { mutableStateOf<String?>(null) }
    var chunks by remember { mutableStateOf<List<String>>(emptyList()) }
    var question by remember { mutableStateOf("") }
    var answer by remember { mutableStateOf("") }
    var busy by remember { mutableStateOf<String?>(null) }
    var err by remember { mutableStateOf("") }
    var ocr by remember { mutableStateOf(false) }
    var strict by remember { mutableStateOf(false) }

    fun openBook(name: String) {
        scope.launch {
            busy = "عم أجهّز الكتاب..."
            try {
                chunks = withContext(Dispatchers.Default) { Books.chunk(Books.load(ctx, name)) }
                current = name; answer = ""; err = ""
            } catch (e: Throwable) { err = "فشل: ${e.message}" }
            busy = null
        }
    }

    fun ask(q: String) {
        if (q.isBlank()) return
        if (!Ai.configured(ctx)) { err = "حط إعدادات الذكاء الاصطناعي أول (الشاشة الرئيسية ← إعدادات الذكاء)"; return }
        err = ""; answer = ""; busy = "عم أدوّر بالكتاب وأجاوب..."
        scope.launch {
            try {
                answer = withContext(Dispatchers.IO) {
                    val top = if (chunks.isEmpty()) emptyList() else Books.top(chunks, q, 6)
                    val text = top.joinToString("\n\n") { (i, t) -> "[${i + 1}] $t" }.ifBlank { "(ما في مقاطع مطابقة)" }
                    val system = if (strict)
                        "أجب فقط من مقاطع الكتاب المرفقة، واذكر رقم المقطع [n]. إذا الجواب مش موجود قل: ما لقيته بالكتاب."
                    else
                        "أنت مدرّس خبير. عندك مقاطع من كتاب. أجب بالاعتماد عليها أولًا واذكر رقم المقطع [n]. " +
                        "إذا الجواب مش بالكتاب أجب من معرفتك العامة وابدأ بجملة: (هذا الجواب من خارج الكتاب). أجب بالعربية بوضوح."
                    Ai.ask(ctx, system, "السؤال: $q\n\nمقاطع من الكتاب:\n$text", 1500)
                }
            } catch (e: Throwable) { err = e.message ?: "خطأ" }
            busy = null
        }
    }

    val bookPicker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocument()) { u: Uri? ->
        u ?: return@rememberLauncherForActivityResult
        scope.launch {
            err = ""; busy = "عم أقرأ الملف..."
            try {
                val name = u.lastPathSegment?.substringAfterLast('/')?.substringBeforeLast('.') ?: "كتاب"
                val isPdf = (ctx.contentResolver.getType(u) ?: "").contains("pdf") || u.toString().lowercase().contains("pdf")
                val text = withContext(Dispatchers.IO) {
                    if (isPdf) Books.extractPdf(ctx, u, ocr) { busy = it } else Books.readText(ctx, u)
                }
                require(text.trim().length > 50) { "ما قدرت أستخرج نص من الملف. جرب تفعيل القراءة بالصور (OCR)." }
                val saved = Books.save(ctx, name, text)
                library = Books.list(ctx)
                openBook(saved)
            } catch (e: Throwable) { err = "فشل: ${e.message}"; busy = null }
        }
    }

    val photoPicker = rememberLauncherForActivityResult(ActivityResultContracts.GetContent()) { u: Uri? ->
        u ?: return@rememberLauncherForActivityResult
        scope.launch {
            err = ""; busy = "عم أقرأ السؤال من الصورة..."
            try {
                val bmp = withContext(Dispatchers.IO) { ctx.contentResolver.openInputStream(u)?.use { BitmapFactory.decodeStream(it) } }
                    ?: error("تعذر فتح الصورة")
                val text = withContext(Dispatchers.IO) {
                    try {
                        Ai.vision(ctx, bmp, "اكتب نص السؤال الموجود بالصورة حرفيًا فقط، بدون أي تعليق أو شرح.",
                            400, "أنت قارئ نصوص دقيق. انسخ النص الظاهر بالصورة كما هو.")
                    } catch (e: Exception) { ImageTools.ocr(ctx, bmp) }
                }
                question = text.trim()
                busy = null
                ask(question)
            } catch (e: Throwable) { err = "فشل: ${e.message}"; busy = null }
        }
    }

    ScreenFrame("كتبي", onBack) {
        Column(Modifier.verticalScroll(rememberScrollState()).padding(bottom = 24.dp)) {
            GradientButton("ارفع كتاب (PDF أو TXT)", Modifier.fillMaxWidth()) {
                Gate.suppress = true; bookPicker.launch(arrayOf("application/pdf", "text/plain"))
            }
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(ocr, { ocr = it })
                Spacer(Modifier.width(8.dp))
                Text("قراءة بالصور OCR (للكتب الممسوحة أو لو النص العربي طلع مقلوب، أبطأ)", color = C.dim, fontSize = 12.sp)
            }
            if (library.isNotEmpty()) {
                Text("كتبك", color = C.text)
                library.forEach { n ->
                    Row(verticalAlignment = Alignment.CenterVertically) {
                        TextButton(onClick = { openBook(n) }) { Text((if (n == current) "● " else "") + n, color = C.cyan) }
                        Spacer(Modifier.weight(1f))
                        TextButton(onClick = { Books.delete(ctx, n); library = Books.list(ctx); if (current == n) { current = null; chunks = emptyList() } }) { Text("حذف", color = C.red) }
                    }
                }
            }
            busy?.let { Spacer(Modifier.height(8.dp)); LinearProgressIndicator(Modifier.fillMaxWidth()); Text(it, color = C.dim, fontSize = 13.sp) }

            Spacer(Modifier.height(12.dp))
            Text(if (current != null) "الكتاب الحالي: $current" else "ما في كتاب مفتوح (بقدر أجاوب من عندي)", color = C.text)
            Row(verticalAlignment = Alignment.CenterVertically) {
                Switch(strict, { strict = it })
                Spacer(Modifier.width(8.dp))
                Text("جاوب من الكتاب فقط", color = C.dim, fontSize = 13.sp)
            }
            OutlinedTextField(question, { question = it }, label = { Text("سؤالك") }, modifier = Modifier.fillMaxWidth())
            Spacer(Modifier.height(8.dp))
            Row(horizontalArrangement = Arrangement.spacedBy(10.dp)) {
                GradientButton("اسأل", Modifier.weight(1f)) { ask(question) }
                GradientButton("صوّر سؤال", Modifier.weight(1f)) { Gate.suppress = true; photoPicker.launch("image/*") }
            }
            if (err.isNotBlank()) Text(err, color = C.amber, modifier = Modifier.padding(top = 8.dp))
            if (answer.isNotBlank()) {
                Spacer(Modifier.height(12.dp))
                Glass(Modifier.fillMaxWidth()) { SelectionContainer { Text(answer, color = C.text, fontSize = 15.sp) } }
            }
        }
    }
}
