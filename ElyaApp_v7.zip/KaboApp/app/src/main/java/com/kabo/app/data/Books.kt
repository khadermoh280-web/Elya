package com.kabo.app.data

import android.content.Context
import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.pdf.PdfRenderer
import android.net.Uri
import com.tom_roush.pdfbox.android.PDFBoxResourceLoader
import com.tom_roush.pdfbox.pdmodel.PDDocument
import com.tom_roush.pdfbox.text.PDFTextStripper
import java.io.File
import kotlin.math.ln
import kotlin.math.min

/** مكتبة كتب: استخراج النص (PDF/TXT)، تقطيع، وبحث BM25 بسيط يفهم العربي. */
object Books {
    private fun dir(ctx: Context) = File(ctx.filesDir, "books").apply { mkdirs() }
    private fun safe(n: String) = n.replace(Regex("[\\\\/:*?\"<>|]"), "_").take(60).ifBlank { "كتاب" }

    fun list(ctx: Context): List<String> =
        dir(ctx).listFiles()?.filter { it.extension == "txt" }?.sortedByDescending { it.lastModified() }
            ?.map { it.nameWithoutExtension }.orEmpty()

    fun save(ctx: Context, name: String, text: String): String {
        val n = safe(name); File(dir(ctx), "$n.txt").writeText(text.take(3_000_000)); return n
    }

    fun load(ctx: Context, name: String): String = File(dir(ctx), "$name.txt").readText()
    fun delete(ctx: Context, name: String) { File(dir(ctx), "$name.txt").delete() }

    fun readText(ctx: Context, uri: Uri): String =
        ctx.contentResolver.openInputStream(uri)?.bufferedReader()?.use { it.readText() } ?: error("تعذر قراءة الملف")

    fun extractPdf(ctx: Context, uri: Uri, ocr: Boolean, onStatus: (String) -> Unit): String {
        if (!ocr) {
            onStatus("عم أستخرج النص من الكتاب...")
            PDFBoxResourceLoader.init(ctx)
            val txt = ctx.contentResolver.openInputStream(uri)!!.use { ins ->
                val doc = PDDocument.load(ins)
                try { PDFTextStripper().getText(doc) } finally { doc.close() }
            }
            if (txt.trim().length > 300) return txt
            onStatus("النص قليل، عم أحوّل لقراءة بالصور (OCR)...")
        }
        return ocrPdf(ctx, uri, onStatus)
    }

    private fun ocrPdf(ctx: Context, uri: Uri, onStatus: (String) -> Unit): String {
        val pfd = ctx.contentResolver.openFileDescriptor(uri, "r") ?: error("تعذر فتح الملف")
        val r = PdfRenderer(pfd)
        try {
            val n = min(r.pageCount, 80)
            val sb = StringBuilder()
            for (i in 0 until n) {
                onStatus("قراءة الصفحة ${i + 1} من $n (OCR)...")
                val page = r.openPage(i)
                try {
                    val w = 1400; val h = (w.toFloat() * page.height / page.width).toInt()
                    val bmp = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888); bmp.eraseColor(Color.WHITE)
                    page.render(bmp, null, null, PdfRenderer.Page.RENDER_MODE_FOR_DISPLAY)
                    sb.append(ImageTools.ocr(ctx, bmp)).append("\n\n")
                } finally { page.close() }
            }
            return sb.toString()
        } finally { r.close(); pfd.close() }
    }

    private fun norm(s: String): String = s.lowercase()
        .replace(Regex("[\\u064B-\\u065F\\u0670\\u0640]"), "")
        .replace('أ', 'ا').replace('إ', 'ا').replace('آ', 'ا').replace('ى', 'ي').replace('ة', 'ه')

    private fun tokens(s: String): List<String> =
        Regex("[\\p{L}\\p{N}]+").findAll(norm(s)).map { m ->
            var w = m.value
            if (w.startsWith("ال") && w.length > 4) w = w.substring(2)
            w
        }.filter { it.length > 1 }.toList()

    fun chunk(text: String, size: Int = 900): List<String> {
        val sents = text.replace(Regex("[ \\t]+"), " ").split(Regex("(?<=[.!؟?\\n])"))
            .map { it.trim() }.filter { it.isNotEmpty() }
        val out = mutableListOf<String>()
        val cur = StringBuilder(); var lastSent = ""
        for (s in sents) {
            if (cur.length + s.length > size && cur.isNotEmpty()) {
                out += cur.toString(); cur.clear()
                if (lastSent.isNotEmpty()) cur.append(lastSent).append(' ')
            }
            cur.append(s).append(' '); lastSent = s
        }
        if (cur.isNotBlank()) out += cur.toString()
        return out
    }

    /** أفضل k مقاطع للسؤال (فهرس المقطع، نصه). */
    fun top(chunks: List<String>, q: String, k: Int = 6): List<Pair<Int, String>> {
        val qt = tokens(q).distinct()
        if (qt.isEmpty() || chunks.isEmpty()) return emptyList()
        val toks = chunks.map { tokens(it) }
        val n = chunks.size
        val avg = toks.sumOf { it.size }.toDouble() / n + 1e-9
        val tf = toks.map { l -> qt.associateWith { t -> l.count { it == t } } }
        val df = qt.associateWith { t -> tf.count { (it[t] ?: 0) > 0 } }
        val scores = toks.indices.map { i ->
            var s = 0.0
            for (t in qt) {
                val f = tf[i][t] ?: 0
                if (f == 0) continue
                val d = df[t] ?: 0
                val idf = ln((n - d + 0.5) / (d + 0.5) + 1)
                s += idf * f * 2.2 / (f + 1.2 * (0.25 + 0.75 * toks[i].size / avg))
            }
            s
        }
        return scores.withIndex().filter { it.value > 0 }.sortedByDescending { it.value }.take(k)
            .map { it.index to chunks[it.index] }
    }
}
