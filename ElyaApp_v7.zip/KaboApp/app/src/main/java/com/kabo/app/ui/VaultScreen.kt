package com.kabo.app.ui

import android.graphics.Bitmap
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.asImageBitmap
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.kabo.app.Gate
import com.kabo.app.data.Vault
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext

@Composable
fun VaultScreen(onBack: () -> Unit) {
    val ctx = LocalContext.current
    val vault = remember { Vault(ctx) }
    var files by remember { mutableStateOf(vault.list()) }
    var open by remember { mutableStateOf<String?>(null) }

    val picker = rememberLauncherForActivityResult(ActivityResultContracts.GetMultipleContents()) { uris ->
        uris.forEach { u -> ctx.contentResolver.openInputStream(u)?.use { vault.add(it.readBytes()) } }
        files = vault.list()
    }

    ScreenFrame("الخزنة", onBack) {
        Glass(Modifier.fillMaxWidth()) {
            Text("صورك مشفرة AES-256 ومفتاحها داخل شريحة الأمان بالجوال. النسخة الأصلية بتضل بالمعرض، احذفها بعد النقل.", color = C.dim, fontSize = 13.sp)
            Spacer(Modifier.height(10.dp))
            GradientButton("+ أضف صور للخزنة", Modifier.fillMaxWidth()) { Gate.suppress = true; picker.launch("image/*") }
        }
        Spacer(Modifier.height(12.dp))
        LazyVerticalGrid(GridCells.Fixed(3), horizontalArrangement = Arrangement.spacedBy(8.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
            items(files, key = { it }) { name ->
                val bmp by produceState<Bitmap?>(null, name) {
                    value = withContext(Dispatchers.IO) {
                        vault.load(name)?.let { b ->
                            val s = 300f / maxOf(b.width, b.height)
                            if (s < 1f) Bitmap.createScaledBitmap(b, (b.width * s).toInt(), (b.height * s).toInt(), true) else b
                        }
                    }
                }
                Box(Modifier.aspectRatio(1f).clip(RoundedCornerShape(16.dp)).background(C.glass).clickableNoRipple { open = name }) {
                    bmp?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxSize(), contentScale = ContentScale.Crop) }
                }
            }
        }
    }

    open?.let { name ->
        val full by produceState<Bitmap?>(null, name) { value = withContext(Dispatchers.IO) { vault.load(name) } }
        AlertDialog(
            onDismissRequest = { open = null },
            confirmButton = { TextButton({ open = null }) { Text("إغلاق") } },
            dismissButton = { TextButton({ vault.delete(name); files = vault.list(); open = null }) { Text("حذف", color = C.red) } },
            text = { full?.let { Image(it.asImageBitmap(), null, Modifier.fillMaxWidth(), contentScale = ContentScale.Fit) } }
        )
    }
}
